package smithJordan_ShapesPhase1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

//***need to make another class extending the JComponent to control how the graphics display - the JComponent
//we'll then add the class with the JComponent into the Frame here!
public class Main extends JFrame {
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() ->{
		
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		JLabel label = new JLabel("(L)ine (E)rase (T)rail (B)ox (O)val (C)olor");

		
		KeyListener boardListener = new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				switch (Character.toUpperCase(e.getKeyChar())) {
				case 'L': System.out.println("L Pressed - Line Mode"); 
					break;
					//we're going to create objects for the different shapes then call up those methods to create lines, boxes. etc.
					
				case 'E': 
					break;
				case 'T': 
					break;
				case 'B':
					break;
				case 'O': 
					break;
				case 'C':
					break;
				}
				
			}
		};
		
		
		final int FRAME_WIDTH = 600;
		final int FRAME_HEIGHT = 600;
		
		panel = new Panel(boardListener);
		panel.add(label, BorderLayout.SOUTH);
		frame.add(new JScrollPane(panel));
		panel.requestFocusInWindow();

		frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		frame.setLocationRelativeTo(null);
		frame.setTitle("Shapes");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		frame.setVisible(true);

	});
	}
}

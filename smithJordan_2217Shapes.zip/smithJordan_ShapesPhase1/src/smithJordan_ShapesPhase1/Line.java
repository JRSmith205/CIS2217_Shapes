//AUTHOR: Jordan Smith
//PROJECT NAME: Shapes Phase 1

package smithJordan_ShapesPhase1;
/**
 * @author Jordan Smith
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


/**
 * This subclass of Shapes is used to differentiate Line from the other shape classes
 */
public class Line extends Shapes {
	/**
	 * default constructor
	 */
	public Line(int x1, int y1,int x2, int y2) {
		super (x1, y1, x2, y2);//super - from the Shapes class (aka parent class)

	}


	
	/**
	 * extending from the parent Shapes class
	 */
	//now what do I do with this? -- gotta somehow display the image of the line being drawn in the panel
	@Override
	public void draw(Graphics g) {
		
		g.setColor(color);
		g.drawLine(x1, y1, x2, y2);
	}

}

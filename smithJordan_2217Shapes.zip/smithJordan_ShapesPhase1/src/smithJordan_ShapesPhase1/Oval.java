//AUTHOR: Jordan Smith
//PROJECT NAME: Shapes Phase 1

package smithJordan_ShapesPhase1;
/**
 * @author Jordan Smith
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


/**
 * This subclass of Shapes is used to differentiate Oval from the other shape classes
 */

 public class Oval extends Shapes {
	 /**
	  * default constructor
	 * @param color 
	 * @param y2 
	 * @param x2 
	 * @param y1 
	 * @param x1 
	  */
	 public Oval(int x1, int y1, int x2, int y2/*, Color color*/) {
		 super(x1, y1, x2, y2/*, color*/);
	 }

	 /**
	  * extending from the parent Shapes class
	  */
	@Override
	public void draw(Graphics g) {
		
		//COPY AND PASTED FROM LINE - CHANGE ANY FORMAULAS ACCORDINGLY
		g.setColor(color);
		g.drawOval(x1, y1, x2, y2);		
	}

}

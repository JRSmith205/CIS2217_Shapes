//AUTHOR: Jordan Smith
//PROJECT NAME: Shapes Phase 1

package smithJordan_ShapesPhase1;
/**
 * @author Jordan Smith
 * @version 1/18/25
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

enum ShapeType{
	LINE, RECTANGLE, OVAL;
}
/**
 The Shapes class will act as the superclass for deriving different shapes like Rectangle/Box, Oval, and Line
 */
 public abstract class Shapes{
	
	
	//data fields - changed the variables to be the starting x,y points where the mouse clicks the screen. The second x,y points are where the mouse ends
	 //changed from private to protected --> private can only be accessed by own class, protected means that any of the subclasses that need it can use it
	protected int x1; //changed these to int because the drawLine method takes int (guess I could have cast as doubl)
	protected int y1;
	protected int x2;
	protected int y2;
	protected Color color;//color is included in the awt? - https://docs.oracle.com/javase/8/docs/api/java/awt/color/package-summary.html
	
	//constructors
	/**
	 * initial constructor
	 */
	public Shapes() {
		
	}

	
	/**
	 * Constructor for the shape's points and color as stated by user when invoked
	 * @param point1 : Point 1 by user
	 * @param point2 : point 2 by user
	 * @param color : color by user
	 */
	public Shapes(int x1, int x2, int y1, int y2) {
		this.x1 = x1;
		this.x2 = x2;
		this.y1 = y1;
		this.y2 = y2;
		this.color = color;
		
	}

	/**
	 * For subclasses to expand upon for their use --> on retrospection, this is to be used for the abstract because the other classes will use this for graphic drawing
	 * @return : allows the subclasses to input their own areas when needed
	 */
	public abstract void draw(Graphics g);


}

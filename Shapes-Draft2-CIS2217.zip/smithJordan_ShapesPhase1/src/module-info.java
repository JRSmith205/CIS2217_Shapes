/**
 * This provides functionality for the project Shapes
 */
module smithJordan_ShapesPhase1 {
	requires java.desktop;
}
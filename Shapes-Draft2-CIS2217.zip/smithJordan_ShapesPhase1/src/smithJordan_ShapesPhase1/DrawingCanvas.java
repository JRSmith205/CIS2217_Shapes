package smithJordan_ShapesPhase1;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Shape;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.swing.JColorChooser;
import javax.swing.JComponent;
import javax.swing.JLabel;

/**
 * The DrawingCanvas class extends JComponent because that controls the components like paint
 */
public class DrawingCanvas extends JComponent{

	ArrayList<Shapes> shapeList = new ArrayList<>();
	//leave the selectedShape blank because this will determine what case we're currently using in addKeyListener
	//this will essentially act as a loop without us having to make one
	private ShapeType selectedShape;
	private Shapes tempShape = null;
	
	private boolean firstTime = true;
	private int x1, y1, x2, y2;
	private Color color;
	
	//need a try-catch to catch if the user doesn't input a key first -->
	//if they don't choose one of the options, the program will ask them to do so
	/**
	 * constructor for the DrawingCanvas class which displays the other classes when their switch is pressed
	 */
	public DrawingCanvas() {
		
		/**
		 * the mouseListener stores the coordinates into the tempShape object then adds the tempShape to the shape array
		 */
		addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed (MouseEvent e) {
				if (firstTime != true) {
					x2 = e.getX();
					y2 = e.getY();
					//if start point and end point are not null --> shapes.add
					System.out.println("Mouse clicked second time");
					System.out.println("Coordinates for x2: " + x2 + "\nCoordinates for y2: " + y2);
					
					
					tempShape = createShapeMethod(x1, y1, x2, y2, color);
					shapeList.add(tempShape);
					firstTime = true;
					repaint();//repaint needs a loop to recreate each image
					
				}
				else {
					x1 = e.getX();
					y1 = e.getY();
					firstTime = false;
					System.out.println("Mouse clicked first time");
					System.out.println("Coordinates for x1: " + x1 + "\nCoordinates for y1: " + y1);
				}
			}
			
			public void mouseRelease(MouseEvent e) {
				tempShape = null;
			}
		});
		
		/**
		 * keyListener listens whenever the selected button is pressed and activates the switch it corresponds to
		 */
		addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				switch (Character.toUpperCase(e.getKeyChar())) {
				//create an object of each given mode so that when each letter is pressed, it calls up that class
				case 'L': selectedShape = ShapeType.LINE; //When l or L are pushed, the selectedShape becomes the constant LINE and will be passed into the createShapes method to actually make the shape appear in graphic
				System.out.println("Line is chosen");
					break;
					//we're going to create objects for the different shapes then call up those methods to create lines, boxes. etc.
					//shapes.add(new Line(start point, end point));
				case 'E': //we've got to clear the arrayList using clear, but it doesn't seem to be clearing it entirely
					//ANSWER: ALWAYS USE repaint() FOR ANYTHING DRAWING RELATED!!!
					shapeList.clear();
					repaint();
					break;
				case 'T': 
					break;
				case 'R': selectedShape = ShapeType.RECTANGLE;
					break;
				case 'O': selectedShape = ShapeType.OVAL;
					break;
				case 'C': 
					color = JColorChooser.showDialog(getComponentPopupMenu(),"Make a choice", color.MAGENTA);
					if(color != null) {
					//why isn't this working? --> REFERENCING MadProgrammer https://stackoverflow.com/questions/65709269/add-a-color-selector-to-a-panel-in-java
					//it was working, I'm just dumb and was missing the JColorChooser.showDialog() ABOVE the if statement
						setBackground(color);
					
				
				}
					break;
				}
				
			}
		});
		
		setFocusable(true);
	}
	
	/**
	 * The createShapeMethod ensures that whatever mode is selected is reflected back on the currentShape object 
	 * This will change .drawLine to .drawOval and so on
	 * @param x1 : coordinate x1
	 * @param y1 : coordinate y1
	 * @param x2: coordinate x2
	 * @param y2 : coordinate y2
	 * @param color : color by user
	 * @return
	 */
	private Shapes createShapeMethod(int x1, int y1, int x2, int y2, Color color) {
		switch (selectedShape) {
		case RECTANGLE: 
			return new Rectangle(x1, y1, x2, y2, color);
		case OVAL:
			return new Oval(x1,y1,x2,y2, color);
		case LINE://when l is selected in the switch above, this will trigger
			return new Line(x1, y1, x2, y2, color);
		default:
			System.out.println("Something went wrong");
		
		}
		return tempShape;
	}
	
	/**
	 * paintComponent will display every stored object currently store in the array
	 * when the user presses (E) for erase, this method will display nothing because there's nothing stored anymore
	 */
    public void paintComponent(Graphics g) {//paintComponent is the method to create all graphics on screen
        super.paintComponent(g);
       
		//how the heck am I supposed to do this???!!!! -->use the array list to essentially keep calling the previous currentShape up with each iteration
        //by calling  up an array, you keep the past shapes data according to their last coordinates and key pressed
        for (Shapes shape : shapeList) {
            shape.draw(g);
        }
   
            
        }
    }
	




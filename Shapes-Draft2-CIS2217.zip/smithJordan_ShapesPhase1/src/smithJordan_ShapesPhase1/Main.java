package smithJordan_ShapesPhase1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

//***need to make another class extending the JComponent to control how the graphics display - the JComponent
//we'll then add the class with the JComponent into the Frame here!
/**
 * this Main class extends JFrame because we're putting the DrawingCanvas inside the mainframe
 */
public class Main extends JFrame {
	
	//**need a global String to pass into the second switch case to call up the different shapes**
	public String selectedShape = "Line";
	
	/**
	 * the main method to ensure the program runs
	 * @param args : everything goes inside this main method
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() ->{
		
		
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		JLabel label = new JLabel("(L)ine (E)rase (T)rail (R)ectangle (O)val (C)olor");

		
		//need another switch case of selected shape --> if case: line, return new line (L calls the line class)
		
		DrawingCanvas drawObject = new DrawingCanvas();
		
		final int FRAME_WIDTH = 600;
		final int FRAME_HEIGHT = 600;
		

		
		
//		panel.add(label, BorderLayout.SOUTH);
//		frame.add(new JScrollPane(panel));
		frame.add(drawObject);
		

		frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		frame.setLocationRelativeTo(null);
		frame.setTitle("Shapes");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		frame.setVisible(true);

	});
	}
}

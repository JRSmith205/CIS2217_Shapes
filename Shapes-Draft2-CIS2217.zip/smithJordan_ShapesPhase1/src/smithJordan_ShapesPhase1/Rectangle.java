//AUTHOR: Jordan Smith
//PROJECT NAME: Shapes Phase 1

package smithJordan_ShapesPhase1;
/**
 * @author Jordan Smith
 */

import java.awt.*;
import java.awt.event.*;
import java.util.regex.Pattern;
import javax.swing.*;

/**
 * This subclass of Shapes is used to differentiate Rectangle from the other shape classes
 */
 public class Rectangle extends Shapes {
	
	 
	 
	 /**
	  * default constructor
	  */
	 public Rectangle(int x1, int y1, int x2, int y2, Color color) {
		 super(x1, y1, x2, y2, color);
	 }

	 /**
	  * extending from the parent Shapes class
	  */
	 //this method 
	@Override
	public void draw(Graphics g) {
		//COPY AND PASTED FROM LINE - CHANGE ANY FORMAULAS ACCORDINGLY
		g.setColor(color);
		g.drawRect(x1, y1, x2, y2);
	}

}

package smithJordan_ShapesPhase1;


//note: This helped me to understand a bit more how mouseEvents can be used https://www.geeksforgeeks.org/mouselistener-mousemotionlistener-java/

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Panel extends JPanel{
	
	private JLabel label;
	private JTextArea textBox;
	private boolean firstTime = true;
	private int x1, y1, x2, y2;
	private String shape;
	
	public Panel() {
		this.shape = shape;
		setFocusable(true);
		
	}
	

//	
//	    public void paintComponent(Graphics g, String shape) {//paintComponent is the method to create all graphics on screen
//	        super.paintComponent(g);
//	        this.setBackground(Color.WHITE);
//	        g.setColor(Color.BLUE);
//	        if (x1 != 0 || y1 != 0 || x2 != 0 || y2 != 0) {
//	        	//create the second switch case to create draw
//	        	switch (shape) {
//	        	case "Line": 
//	        		Line line = new Line(x1, y1, x2, y2);
//	        		line.draw(g);
//	        		//create new object and object.draw()
//	        		break;
//	        	case "Box": 
//	        		break;
//	        	case "Oval": 
//	        		break;
//	        	}
////	        	g.drawLine(x1, y1, x2, y2);
//	            
//	        }
//	    }
	

}
